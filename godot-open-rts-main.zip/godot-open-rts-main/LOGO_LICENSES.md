# `assets/logos/godot_logo_vertical_monochrome_dark_312x357.png`

Godot Engine Logo Copyright (c) 2017 Andrea Calabró

This logo is licensed under a Creative Commons Attribution 4.0 International License (CC-BY-4.0 International) https://creativecommons.org/licenses/by/4.0/.

See https://github.com/godotengine/godot

# `assets/logos/lampe_games_white.svg`

Lampe Games Logo Copyright (c) 2022

This logo is fully owned (all rights reserved) by Lampe Games and should not be used in any projects derived from original https://github.com/lampe-games/godot-open-rts project.
